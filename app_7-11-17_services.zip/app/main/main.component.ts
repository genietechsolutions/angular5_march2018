import { Component, OnInit } from '@angular/core';

import {MyserviceService} from '../myservice.service';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css'],
  providers:[MyserviceService]
})
export class MainComponent implements OnInit {
  local=new MyserviceService;

  constructor() { }
 
  ngOnInit() {
    console.log('main componenet'+this.local.record);
 }

}
