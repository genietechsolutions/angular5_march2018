import { Injectable } from '@angular/core';

@Injectable()
export class MyserviceService {
  record="venkat";
  constructor() { }

}

const data=[10,20,30,50,40,80,90];