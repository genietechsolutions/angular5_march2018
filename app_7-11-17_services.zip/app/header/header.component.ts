import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  marks=[30,40,50,60,70,80,90,10];
  constructor() { }

  ngOnInit() {
  }

}
