import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SpaRoutingModule } from './spa-routing.module';

@NgModule({
  imports: [
    CommonModule,
    SpaRoutingModule
  ],
  declarations: []
})
export class SpaModule { }
