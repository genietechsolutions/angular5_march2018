import { Component, OnInit, OnDestroy, OnChanges } from '@angular/core';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit, OnDestroy {
  mydata:any='welcome';check:any;
  no=[1,2,3,4,5,6,7,8,9];
  constructor() { }

  ngOnInit() {
    console.log("contact loaded");
  }
  ngOnDestroy() {
    console.log("destoryed contact");
  }
  // ngOnChanges() {
  //   console.log(this.mydata);
  // }
}
