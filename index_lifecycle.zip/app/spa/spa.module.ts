import {NgModule, ModuleWithProviders} from '@angular/core';
import {CommonModule} from '@angular/common';
import {Routes,RouterModule} from '@angular/router';


import { SpaRoutingModule } from './spa-routing.module';

@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    SpaRoutingModule
  ],
  exports:[SpaRoutingModule],
  declarations: []
})
export class SpaModule { }


