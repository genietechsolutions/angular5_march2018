
export class Records {
    name: string;
    desg: string;
    desc: string;
  }
  
  export const EmpRecords = [
    {'name':'venkat','desg':'software Employee','desc':''},
    {'name':'Raju','desg':'software Employee','desc':''},
    {'name':'Rani','desg':'software Employee','desc':''}
  ];

  