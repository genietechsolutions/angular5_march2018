import { Component, OnInit,  EventEmitter, Input, Output  } from '@angular/core';
import {Records} from '../records'

@Component({
  selector: 'app-aboutinner',
  templateUrl: './aboutinner.component.html',
  styleUrls: ['./aboutinner.component.css']
})
export class AboutinnerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  edit=true;
  desc='';
  data:any;
  @Input() moreData: Records;
  @Output() moreDesc = new EventEmitter<any>();

  updated(moreData,desc){
    moreData.desc=desc;
    this.desc='';
    this.moreDesc.emit(moreData);

  }
}
