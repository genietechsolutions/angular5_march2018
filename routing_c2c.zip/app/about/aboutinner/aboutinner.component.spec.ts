import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AboutinnerComponent } from './aboutinner.component';

describe('AboutinnerComponent', () => {
  let component: AboutinnerComponent;
  let fixture: ComponentFixture<AboutinnerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AboutinnerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AboutinnerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
