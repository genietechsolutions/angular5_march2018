import { Component, OnInit,  EventEmitter, Input, Output  } from '@angular/core';
import {Records} from '../records'

@Component({
  selector: 'app-aboutinner',
  templateUrl: './aboutinner.component.html',
  styleUrls: ['./aboutinner.component.css']
})
export class AboutinnerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  edit=true;
  desc='';
  data:any;
  @Input() moreData: Records;
  @Output() addDesc = new EventEmitter<any>();

  updated(moreData,desc){
    this.desc='';
    this.data={"state":moreData,'desc':desc}
    this.addDesc.emit(this.data);

  }
}
