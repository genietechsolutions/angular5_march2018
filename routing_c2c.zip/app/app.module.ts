import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import {NgClass} from '@angular/common';
import {Routes, RouterModule} from '@angular/router';
import {SpaModule} from './spa/spa.module';
import {HttpModule} from '@angular/http';
import {StudentService} from './student.service';






import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import {ProjectsComponent} from  './projects/projects.component';
import{SignupComponent} from './signup/signup.component';
import{SigninComponent} from './signin/signin.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { AboutinnerComponent } from './about/aboutinner/aboutinner.component';
import { HomedetailComponent } from './home/homedetail/homedetail.component';
import { ChildComponent } from './home/homedetail/child/child.component';
import { Child2Component } from './home/homedetail/child2/child2.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AboutComponent,
    ContactComponent,
    ProjectsComponent,
    SignupComponent,
    SigninComponent,
    PagenotfoundComponent,
    AboutinnerComponent,
    HomedetailComponent,
    ChildComponent,
    Child2Component
  ],
  imports: [
    BrowserModule,FormsModule,SpaModule,HttpModule
  ],
  providers: [StudentService],
  bootstrap: [AppComponent]
})
export class AppModule { }
