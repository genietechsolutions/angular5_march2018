import {NgModule, ModuleWithProviders} from '@angular/core';
import {CommonModule} from '@angular/common';
import {Routes,RouterModule} from '@angular/router';


import { HomeComponent } from '../home/home.component';
import { AboutComponent } from '../about/about.component';
import { ContactComponent } from '../contact/contact.component';
import {ProjectsComponent} from  '../projects/projects.component';
import{SignupComponent} from '../signup/signup.component';
import {SigninComponent} from '../signin/signin.component';
import { PagenotfoundComponent } from '../pagenotfound/pagenotfound.component';
import { HomedetailComponent } from '../home/homedetail/homedetail.component';
import { ChildComponent } from '../home/homedetail/child/child.component';
import { Child2Component } from '../home/homedetail/child2/child2.component';






const routes: Routes =[
    {path: 'home', component: HomeComponent},
    {path: 'homedetail/:id', component: HomedetailComponent,
    children: [
        { path: 'page1', component: ChildComponent },
        { path: 'page2', component: Child2Component }
      ]
    },
    {path: 'about', component: AboutComponent},
    {path: 'projects', component:ProjectsComponent},
    {path: 'contact', component: ContactComponent},
    {path: 'signup', component:SignupComponent, outlet: 'customRoute'},
    {path: 'signin', component:SigninComponent, outlet: 'customRoute'},
    {path: '', component: HomeComponent},
    {path: '**', component: PagenotfoundComponent},
];


@NgModule ({
    imports: [RouterModule.forRoot(routes) ],
    exports: [RouterModule]
})

export class SpaRoutingModule{

}

export const routing: SpaRoutingModule = RouterModule.forRoot(routes);