import { Component, Input, OnInit, OnChanges, SimpleChanges } from '@angular/core';


@Component({
  selector: 'app-c2',
  templateUrl: './c2.component.html',
  styleUrls: ['./c2.component.css']
})
export class C2Component implements OnInit, OnChanges  {

  @Input() innerData: string;
  @Input() innerState: boolean;

  ngOnChanges(changes: SimpleChanges) {
    for (let propertyName in changes) {
        let change = changes[propertyName];
        let current = JSON.stringify(change.currentValue);
        let previous = JSON.stringify(change.previousValue);
        console.log(propertyName + ': currentValue = '
            + current + ', previousValue = ' + previous);
    }
}
constructor() { }

  ngOnInit() {
    console.log(this.innerData);
  }
}
