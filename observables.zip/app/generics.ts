export class Generics{
  id:number;
  name:string;
  
  constructor(){}
}