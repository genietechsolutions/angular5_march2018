import { Component, OnInit } from '@angular/core';
import {Observable} from 'rxjs';
import {StudentService} from '../student.service';
import {Generics} from '../generics';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
    studentsObservable:Observable<Generics[]>;
    generics:Generics[];
    errorMessage:string;
  constructor(private studentService:StudentService) {
    
   }

  ngOnInit(): void {
    this.studentsObservable=  this.studentService.getStudentsData();
console.log(this.studentsObservable);
    this.studentsObservable.subscribe(
      generics=>this.generics=generics,
            error=>this.errorMessage=<any>error);
    
  }

  postData(){
    alert('test');
    var localPost = this.studentService.postStudentsData();
    localPost.subscribe(
            generics=>console.log('values inserted'),
            error=>console.log('values are not inserted')
    )
  }

}
