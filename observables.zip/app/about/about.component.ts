import { EventEmitter } from 'events';
import { Component, OnInit } from '@angular/core';
import {EmpRecords} from './records'
@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {
  show=true;
  records = EmpRecords;
  data:any;
  constructor() { 
   // this.data.state=this.records[0];
    //this.data.desc='welcome';
   // this.addDesc(this.records[0],'welcome');
  }
  
  
  ngOnInit() {
  }
  addDesc(data:any){
    console.log(data);
   // data.state.desc=data.desc;
  }
  
}

// 1. <appchild (moreDesc)="addDesc($event)">
// 2. import {output, EventEmitter} from '@angular/core' 
// 3. @ouput moreDesc : new EventEmitter(any);
// 4. updateDesc(){
//   this.moreDesc.Emit(moreData)
// }

// -------> component life cycle 

// 1. import {ngOninit, ngOnidestory, ngonChanges} from '@angluar/core'

// 2. export class Services impliments ngOnit, ngondestory, ngonchanges{


// 3. ngoninit(){}
// 4. ngonChanges(){}
// 5. ngonDestory(){}

// } 