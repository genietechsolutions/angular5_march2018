import { MystyleDirective } from './mystyle.directive';

describe('MystyleDirective', () => {
  it('should create an instance', () => {
    const directive = new MystyleDirective();
    expect(directive).toBeTruthy();
  });
});
