import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
  name="Hari";
  x:number=202005050630;
  y:string="VENKAT";
  z:Date=new Date();
  no:number=10;
  marks=[10,20,30,40,50,60];
  data=[
    {'no':1,'name':'venkat'},
    {'no':1,'name':'venkat'},
    {'no':1,'name':'venkat'},
    {'no':1,'name':'venkat'}
  ]
  result="pass";
  validate() {
    alert(this.result);
  }
}

