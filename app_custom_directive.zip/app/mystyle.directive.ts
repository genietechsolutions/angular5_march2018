import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: '[appMystyle]'
})
export class MystyleDirective {
  constructor(private el: ElementRef) {
      el.nativeElement.style.color='white';
      el.nativeElement.style.background='red'; 
   }
   @HostListener('mouseenter') onMouseEnter() {
    this.el.nativeElement.style.background='blue'; 
  }
  @HostListener('mouseout') onMouseOut() {
    this.el.nativeElement.style.background='green'; 
  }

}
