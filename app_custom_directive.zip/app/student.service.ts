import { Injectable } from '@angular/core';
import {Http,Response} from '@angular/http';
import {Observable} from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';

import {Generics} from './generics';


@Injectable()
export class StudentService {
   url="http://localhost:3000/posts/";


  constructor(private http:Http) {

   }
   getStudentsData():Observable<Generics[]>{
         return this.http.get(this.url)
         .map(this.myData)
         .catch(this.handleErrorObservable);
         
   }

   private myData( resp: Response)
   {
     let studentsRecord=resp.json();
     return studentsRecord;
   }
   private handleErrorObservable (error: Response | any) {
	//	console.error(error.message || error);
		return Observable.throw(error.message || error);
    }

}
