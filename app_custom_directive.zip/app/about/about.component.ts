import { Component, OnInit } from '@angular/core';
import {EmpRecords} from './records'
@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {
  show=true;
  records = EmpRecords;
  data:any;
  constructor() { 
   // this.data.state=this.records[0];
    //this.data.desc='welcome';
   // this.addDesc(this.records[0],'welcome');
  }
  
  
  ngOnInit() {
  }
  addDesc(data:any){
    console.log(data);
    data.state.desc=data.desc;
  }
  
}
