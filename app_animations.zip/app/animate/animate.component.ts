import { Component, OnInit, trigger, state, style, transition, animate, keyframes } from '@angular/core';

@Component({
  selector: 'app-animate',
  templateUrl: './animate.component.html',
  styleUrls: ['./animate.component.css'],
  animations:[
    trigger('myTrigger',[
        state('small',style({
          transform:'scale(1)'
      })),
        state('large',style({
          transform:'scale(2)'
        })),
        transition('small <=> large', animate('500ms'))
    ])
  ]
})
export class AnimateComponent implements OnInit {
  state:string='small';
  constructor() { }

  ngOnInit() {
  }
  change(){
    this.state=(this.state==='small'?'large':'small');
  }

}
